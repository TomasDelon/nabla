See [[Analyse#^thm-main]].
