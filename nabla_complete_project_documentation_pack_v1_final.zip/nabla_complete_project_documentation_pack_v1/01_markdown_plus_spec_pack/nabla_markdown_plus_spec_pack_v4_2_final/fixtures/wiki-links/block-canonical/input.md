See [[Analyse^thm-main]].
