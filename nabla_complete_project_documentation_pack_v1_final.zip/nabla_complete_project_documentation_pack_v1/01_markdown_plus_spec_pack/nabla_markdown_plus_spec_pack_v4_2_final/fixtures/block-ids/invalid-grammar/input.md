Text. ^1bad
