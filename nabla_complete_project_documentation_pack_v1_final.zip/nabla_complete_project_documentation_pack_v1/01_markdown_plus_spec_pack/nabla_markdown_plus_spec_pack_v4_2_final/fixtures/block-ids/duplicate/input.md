First. ^dup

Second. ^dup
