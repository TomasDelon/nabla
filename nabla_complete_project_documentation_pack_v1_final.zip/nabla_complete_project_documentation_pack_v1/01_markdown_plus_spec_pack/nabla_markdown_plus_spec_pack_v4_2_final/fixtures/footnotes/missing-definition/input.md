Text[^missing].
