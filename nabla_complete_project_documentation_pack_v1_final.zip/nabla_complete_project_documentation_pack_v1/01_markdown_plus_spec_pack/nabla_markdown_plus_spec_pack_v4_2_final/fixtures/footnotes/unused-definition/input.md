Text.

[^unused]: Unused.
