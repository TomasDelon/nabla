word^[missing
