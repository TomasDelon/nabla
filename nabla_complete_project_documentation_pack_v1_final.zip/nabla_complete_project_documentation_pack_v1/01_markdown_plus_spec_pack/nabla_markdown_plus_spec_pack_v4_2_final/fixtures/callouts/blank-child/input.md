[!note] Text
	First.

	Second.
